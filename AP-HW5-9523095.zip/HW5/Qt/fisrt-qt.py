import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QLabel, QVBoxLayout
from PyQt5 import QtGui, QtSql
from PyQt5.QtGui import QPixmap, QIcon
from PyQt5 import QtCore
from PyQt5 import uic
import os
from time import sleep
import sqlite3
import requests


conn = sqlite3.connect('locationDB.db')

#c_t = "CREATE TABLE users (id integer primary key autoincrement, name text, phone integer, username text, password text)"
#d_t = "DROP TABLE user "
#show_table = 'SELECT name from sqlite_master where type = "TABLE" '
conn.execute('''CREATE TABLE IF NOT EXISTS  Users
         (ID INTEGER PRIMARY KEY     NOT NULL,
            username   TEXT    NOT NULL,
            phone     INTEGER,
            password    TEXT);''')

conn.execute('''CREATE TABLE IF NOT EXISTS  Locations
         (ID INTEGER PRIMARY KEY     NOT NULL,
         user_id INTEGER    NOT NULL,
         lat    INTEGER 
         lon     integer );''')


cur = conn.cursor()
x = cur.execute("""SELECT name FROM sqlite_master WHERE type='table'""");
print(x.fetchall())
print("Table created successfully");

stmt = "INSERT INTO Users(username,password,phone) values(?,?,?)"
args = ("sadeghghasr", 11111111,"09355555555")
cur.execute(stmt, args)

stmt = "INSERT INTO Users(username,password,phone) values(?,?,?)"
args = ("Alighasr", "sdcsdcsdcsd","09366666666")
cur.execute(stmt, args)

x = cur.execute("SELECT * FROM Users")
print(x.fetchall())

form = uic.loadUiType(os.path.join(os.getcwd(), 'first_qt.ui'))[0]
register = uic.loadUiType(os.path.join(os.getcwd(), 'register.ui'))[0]
main_win = uic.loadUiType(os.path.join(os.getcwd(), 'API.ui'))[0]

class map (form, QMainWindow):
    def __init__(self):
        form.__init__(self)
        QMainWindow.__init__(self)
        self.setupUi(self)
        self.new_win = 0
        self.pushButton.clicked.connect(self.registering)
        self.pushButton2.clicked.connect(self.test)
        sleep(1)
        self.pushButton2.clicked.connect(self.loginning)
        self.txt = self.lineEdit.text()

    def get_username(self):
        return self.lineEdit.text()

    def get_pass(self):
        return self.lineEdit_2.text()

    def registering(self):
        self.setVisible(0)
        self.new_win = reg()
        self.new_win.show()

    def test(self):
        self.list = []
        ttt = self.get_username()
        x2 = cur.execute("SELECT username,password FROM Users WHERE username =? AND password = ?",
                         (ttt, self.get_pass()))
        print(x2.fetchall())
        self.list.append(x2)

    def loginning(self):
        self.setVisible(0)
        self.new_win = mmm()
        self.new_win.show()


class reg (register, QMainWindow):
    def __init__(self):
        register.__init__(self)
        QMainWindow.__init__(self)
        self.setupUi(self)


class mmm(main_win, QMainWindow):
    def __init__(self):
        main_win.__init__(self)
        QMainWindow.__init__(self)
        self.setupUi(self)
        print("DcsdcD")
        self.SHOW.clicked.connect(self.final)
        sleep(1)
        self.SHOW.clicked.connect(self.setPic)

    def final(self):

        self.mylon = self.Lon.text()
        self.mylat = self.Lat.text()
        print(self.mylat)
        self.response = requests.get('https://map.ir/static', params={'width': 512, 'height': 512, 'zoom_level': 4,
                                                                      'markers': 'color:origin|label:Map|' + str(
                                                                          self.mylon) + ',' + str(self.mylat)},
                                     headers={
                                         'x-api-key': 'WsLdHK46I5Wfr5xgI0ynjjyiw9Fyhydu'})

        print("est")

        image = self.response.content
        with open('location.png', 'wb') as fa:
            fa.write(image)
        print("est33")
    def setPic(self):
        pimap = QPixmap('location.png')
        self.label_5.setPixmap(pimap)



app = QApplication(sys.argv)
f = map()
f.show()
sys.exit(app.exec_())

