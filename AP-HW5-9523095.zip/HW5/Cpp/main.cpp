#include<iostream>
#include<vector>
#include<numeric>
#include<iterator>
#include<algorithm>
#include <bits/stdc++.h>



template <typename T>
void disp(std::vector<int>);

bool IsOdd(int i) 
{ 
    return i % 2; 
} 



int main()
{
	std::vector<int> vec1(100,4);
	std::vector<int> vec2(10);
	// Part A:
	std::iota(vec1.begin(),vec1.end(),1);
	std::iota(vec2.begin(),vec2.end(),1);
	disp(vec1)
	disp(vec2)
	// Part B:
	vec2.insert(vec2.end(),vec1.begin(),vec1.end());
	std::copy(vec2.begin(),vec2.end(),std::ostream_iterator<int>(std::cout," , "));
	std::cout << std::endl;
	disp(vec1)
	disp(vec2)
	//Part C:
	std::vector<int> odd_vec(vec1.size());
	auto odd_vec_end = std::copy_if(vec1.begin(), vec1.end(),odd_vec.begin(),[](int n){return n%2 == 1;});
	odd_vec.erase(odd_vec_end,odd_vec.end());
	std::copy(odd_vec.begin(),odd_vec.end(),std::ostream_iterator<int>(std::cout," ,"));
	std::cout << std::endl;
	disp(vec1)
	disp(vec2)
	// Part D :
	std::vector<int> reverse_vector;
	std::reverse(vec1.begin(),vec1.end());
	reverse_vector=vec1;
	std::copy(reverse_vector.begin(),reverse_vector.end(),std::ostream_iterator<int>(std::cout," ,"));
	std::cout << std::endl;
	disp(vec1)
	disp(vec2)
    return 0;
}

template<typename T>
void disp(std::vector<int> v)
{
	if (std::all_of(v.cbegin(), v.cend(), [](int i) { std::cout << i << ","; return 1; }))
	{
	}
	std::cout << std::endl;
}
