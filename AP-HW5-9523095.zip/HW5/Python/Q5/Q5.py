import os
from os.path import isfile, join
import pathlib

def create_dir(name, address):

    All = [f for f in os.listdir(address) if not isfile(join(address, f))]
    print(All)
    if (name not in All):
        os.chdir(address)
        os.mkdir(name)
    All = [f for f in os.listdir(address) if not isfile(join(address, f))]
    print(All)



def create_file(name , address):

    All = [f for f in os.listdir(address) if isfile(join(address, f))]
    print(All)
    if (name not in All):
        os.chdir(address)
        pathlib.Path(join(address, name)).touch()
    All = [f for f in os.listdir(address) if isfile(join(address, f))]
    print(All)

def delete_file(name , address):

    All = [f for f in os.listdir(address) if isfile(join(address, f))]
    print(All)
    if (name in All):
        os.chdir(address)
        os.remove(os.path.join(address, name) )
    All = [f for f in os.listdir(address) if isfile(join(address, f))]
    print(All)


def find(name, address) :
    ls = []
    for root, dirs, files in os.walk(address):
        for i in files:
            if i == name:
                ls.append(root + '\\' + name)
    print(ls)

find("hassan.mp3" , "E:\\university\\AP-winter97\\HW5\\solution" )