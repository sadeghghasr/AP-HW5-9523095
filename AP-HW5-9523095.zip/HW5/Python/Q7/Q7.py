print("the special numbers are : ", [j for (i, j) in enumerate([int(x) for x in input("Enter a list of numbers that seprate by space : \n ").split()]) if j % 6 == 0 and (i + 1) % 6 == 0])
