import threading
from time import sleep
import logging

logging.basicConfig(format='%(threadName)s %(message)s', level=logging.DEBUG)
def worker():
    logging.debug('started')
    sleep(1)
    logging.debug('finished')


threads = []
for i in range(6):
    t = threading.Thread(target=worker, name=f"Thread{i}")
    threads.append(t)
    t.daemon = True
    threads[-1].start()
sleep(10)
print("fvdfvdfverveV")
print([i.getName() for i in threading.enumerate()])
