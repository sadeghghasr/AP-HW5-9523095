import numpy as np
import math
from numpy.core import integer
import subprocess
import matplotlib.pyplot as plt
from time import time as epochtime

class CGS:
    def __init__(self, func, a, b, n):
        self.function = func
        self.m_A = float(a)
        self.m_B = float(b)
        self.m_N = n
        self.m_Result = 0
    def legendre(self, m_N, x):
        if m_N == 0:
            return 1
        elif m_N == 1:
            return x
        else:
            return ((2.0 * m_N - 1) / m_N) * x * self.legendre(m_N - 1, x) - ((1.0 * m_N - 1) / m_N) * self.legendre(m_N - 2, x)

    def dLegendre(self, m_N, x):
        dLeg = (1.0 * m_N / (x * x - 1.0)) * ((x * self.legendre(m_N, x)) - self.legendre(m_N - 1.0, x))
        return dLeg

    def legendreZeroes(self, m_N, k):
        k = k +1
        pi = 3.141592
        xold1 = np.cos(pi * (k - 1 / 4.0) / (m_N + 1 / 2.0))
        iteration = 1
        while True:
            if iteration != 1:
                xold1 = xnew1
            xnew1 = xold1 - self.legendre(m_N, xold1) / self.dLegendre(m_N, xold1)
            iteration += 1
            if (1 + abs(xnew1 - xold1)) <= 1.0:
                break
        return xnew1


    def weight(self, m_N, x):
        weightI = 2 / ((1.0 - x**2.0) * self.dLegendre(m_N, x)**2)
        return weightI

    def exec(self):
        iteration = 1
        iteration = iteration + 1
        integral = 0.0
        for i in range(self.m_N):
            integral = integral + \
                       self.function(self.legendreZeroes(self.m_N, i)) * self.weight(self.m_N, self.legendreZeroes(self.m_N, i))
            self.m_Result = ((self.m_B - self.m_A)/2.0) * integral

    def getResult(self):
        return self.m_Result


def aFunction(x):
    xN = (0.5 * x) + 0.5
    return ((xN**3)/(xN + 1)) * np.cos(xN**2)

#main :


#x = input("please enter the legendre degree \n")
python = []
cpp = []
for i in range(3, 9):
    time = epochtime()
    x = i
    n = int(float(x))
    a, b = 0, 1
    aSolver = CGS(lambda y: aFunction(y), a, b, n)
    aSolver.exec()
    print("the resule is : ", aSolver.getResult())
    python.append(epochtime() - time)

for i in range(3, 9):
    time2 = epochtime()
    subprocess.call(["IntegrateC++.exe", str(3)])
    cpp.append(epochtime() - time2)


fig, ax = plt.subplots()

# Hide axes
ax.xaxis.set_visible(False)
ax.yaxis.set_visible(False)

# Table from Ed Smith answer
clust_data = [["Cpp :",cpp[0],cpp[1], cpp[2],cpp[3],cpp[4],cpp[5]], ["Python :",python[0],python[1],python[2],python[3],python[4],python[5]]]

collabel = ("", "3", "4", "5", "6", "7", "8")
ax.table(cellText=clust_data, colLabels=collabel, loc='center')
plt.show()