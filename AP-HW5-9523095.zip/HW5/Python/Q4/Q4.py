import math
import random
import sys



global cnt
cnt = 0

def Average(lst):
    return sum(lst) / len(lst)

def IsInSquare(x, y):
    if -0.5 <= x <= 0.5 and -0.5 <= y <= 0.5:
        print(f"point ( {x} , {y}) is in Square")

def IsInCircle(x, y):
    if math.sqrt(x**2 + y**2) <= 0.5:
     #   print(f"point ( {x} , {y}) is in Circle")
        return 1
    else:
    #    print(f"point ( {x} , {y}) is Not in Circle")
        return 0

def find():
    global cnt
    cnt = cnt + 1
    temp = []
    for _ in range(2):
        num_of_in = 0
        num_of_out = 0
        var = []
        for _ in range(cnt):
            a = (random.uniform(0, 0.5), random.uniform(0, 0.5))
            var.append(a)
            if (IsInCircle(a[0], a[1])):
                num_of_in = num_of_in + 1
            else:
                num_of_out = num_of_out + 1

        Pi = 4 * num_of_in / cnt
        if 3.13 < Pi < 3.15:
            temp.append(Pi)

    if len(temp) == 2:
        print("the least number is", cnt)
        print(Average(temp))
        avg = Average(temp)
        return Average(temp)
    else:
        return find()


sys.setrecursionlimit(15000)

Test =[]

i_p = int(input("Please Enter a Number :"))

for _ in range(i_p):
    Test.append(find())

print ("the final Pi number is : ",Average(Test))

